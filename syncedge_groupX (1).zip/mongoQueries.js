db.getCollection("users").find({})
db.getCollection("tasks").find({})
db.getCollection("groups").find({})
//db.getCollection("users").remove({})
