const config = {
    //apiUrl: 'http://localhost:5000', // Replace with your actual API domain
    apiUrl: 'https://is-task-management-app.vercel.app'
};

export default config;